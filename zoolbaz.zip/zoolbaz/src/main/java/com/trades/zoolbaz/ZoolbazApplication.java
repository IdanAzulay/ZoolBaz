package com.trades.zoolbaz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoolbazApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoolbazApplication.class, args);
	}

}
