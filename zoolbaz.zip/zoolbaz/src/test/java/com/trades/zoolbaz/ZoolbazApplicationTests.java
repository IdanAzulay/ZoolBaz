package com.trades.zoolbaz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZoolbazApplicationTests {

	@Test
	void contextLoads() {
	}

}
